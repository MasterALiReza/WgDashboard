CREATE TABLE "DashboardLog" (
	"LogID" VARCHAR(255) NOT NULL, 
	"LogDate" DATETIME DEFAULT CURRENT_TIMESTAMP, 
	"URL" VARCHAR(255), 
	"IP" VARCHAR(255), 
	"Status" VARCHAR(255) NOT NULL, 
	"Message" TEXT, 
	PRIMARY KEY ("LogID")
);
CREATE TABLE "JobLog" (
	"LogID" VARCHAR(255) NOT NULL, 
	"JobID" VARCHAR(255) NOT NULL, 
	"LogDate" DATETIME DEFAULT CURRENT_TIMESTAMP, 
	"Status" VARCHAR(255) NOT NULL, 
	"Message" TEXT, 
	PRIMARY KEY ("LogID")
);
INSERT INTO "DashboardLog" ("LogID", "LogDate", "URL", "IP", "Status", "Message") VALUES ('f39cb6ed-7db9-406f-b07b-77f9cef71459', '2026-07-10 18:01:24', '', '', 'true', 'WGDashboard started');
INSERT INTO "DashboardLog" ("LogID", "LogDate", "URL", "IP", "Status", "Message") VALUES ('2507bc92-605f-48c0-a468-a91ed7559c4b', '2026-07-10 18:02:29', '', '', 'true', 'WGDashboard started');
INSERT INTO "DashboardLog" ("LogID", "LogDate", "URL", "IP", "Status", "Message") VALUES ('c465b35f-127c-41c0-9955-05730e907b24', '2026-07-10 18:02:29', '', '', 'true', 'WGDashboard started');
INSERT INTO "DashboardLog" ("LogID", "LogDate", "URL", "IP", "Status", "Message") VALUES ('04357f82-612f-4501-822f-7c8d51de1611', '2026-07-10 18:02:29', '', '', 'true', 'WGDashboard started');
INSERT INTO "DashboardLog" ("LogID", "LogDate", "URL", "IP", "Status", "Message") VALUES ('7596a41b-c096-4696-ab9d-f587f72c2d9e', '2026-07-16 12:27:01', '', '', 'true', 'WGDashboard started');
INSERT INTO "DashboardLog" ("LogID", "LogDate", "URL", "IP", "Status", "Message") VALUES ('63bc073d-9d16-48d7-b454-7760fbf5646b', '2026-07-16 12:27:01', '', '', 'true', 'WGDashboard started');
INSERT INTO "DashboardLog" ("LogID", "LogDate", "URL", "IP", "Status", "Message") VALUES ('12df661a-869d-4ab2-92d2-abf6f4f4a35f', '2026-07-16 12:27:01', '', '', 'true', 'WGDashboard started');