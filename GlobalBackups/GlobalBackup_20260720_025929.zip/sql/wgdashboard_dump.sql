CREATE TABLE "ConfigurationsInfo" (
	"ID" VARCHAR(255) NOT NULL, 
	"Info" TEXT, 
	PRIMARY KEY ("ID")
);
CREATE TABLE "DashboardAPIKeys" (
	"Key" VARCHAR(255) NOT NULL, 
	"CreatedAt" DATETIME DEFAULT CURRENT_TIMESTAMP, 
	"ExpiredAt" DATETIME, 
	PRIMARY KEY ("Key")
);
CREATE TABLE "DashboardClients" (
	"ClientID" VARCHAR(255) NOT NULL, 
	"Email" VARCHAR(255) NOT NULL, 
	"Password" VARCHAR(500), 
	"TotpKey" VARCHAR(500), 
	"TotpKeyVerified" INTEGER, 
	"CreatedDate" DATETIME DEFAULT CURRENT_TIMESTAMP, 
	"DeletedDate" DATETIME, 
	PRIMARY KEY ("ClientID")
);
CREATE TABLE "DashboardClientsInfo" (
	"ClientID" VARCHAR(255) NOT NULL, 
	"Name" VARCHAR(500), 
	PRIMARY KEY ("ClientID")
);
CREATE TABLE "DashboardClientsPasswordResetLinks" (
	"ResetToken" VARCHAR(255) NOT NULL, 
	"ClientID" VARCHAR(255) NOT NULL, 
	"CreatedDate" DATETIME DEFAULT CURRENT_TIMESTAMP, 
	"ExpiryDate" DATETIME, 
	PRIMARY KEY ("ResetToken")
);
CREATE TABLE "DashboardClientsPeerAssignment" (
	"AssignmentID" VARCHAR(255) NOT NULL, 
	"ClientID" VARCHAR(255) NOT NULL, 
	"ConfigurationName" VARCHAR(255), 
	"PeerID" VARCHAR(500), 
	"AssignedDate" DATETIME DEFAULT CURRENT_TIMESTAMP, 
	"UnassignedDate" DATETIME, 
	PRIMARY KEY ("AssignmentID")
);
CREATE TABLE "DashboardClientsTOTPTokens" (
	"Token" VARCHAR(500) NOT NULL, 
	"ClientID" VARCHAR(500), 
	"ExpireTime" DATETIME, 
	PRIMARY KEY ("Token")
);
CREATE TABLE "DashboardOIDCClients" (
	"ClientID" VARCHAR(255) NOT NULL, 
	"Email" VARCHAR(255) NOT NULL, 
	"ProviderIssuer" VARCHAR(500) NOT NULL, 
	"ProviderSubject" VARCHAR(500) NOT NULL, 
	"CreatedDate" DATETIME DEFAULT CURRENT_TIMESTAMP, 
	"DeletedDate" DATETIME, 
	PRIMARY KEY ("ClientID")
);
CREATE TABLE "DashboardWebHookSessions" (
	"WebHookSessionID" VARCHAR(255) NOT NULL, 
	"WebHookID" VARCHAR(255) NOT NULL, 
	"StartDate" DATETIME DEFAULT CURRENT_TIMESTAMP NOT NULL, 
	"EndDate" DATETIME, 
	"Data" JSON, 
	"Status" INTEGER, 
	"Logs" JSON, 
	PRIMARY KEY ("WebHookSessionID")
);
CREATE TABLE "DashboardWebHooks" (
	"WebHookID" VARCHAR(255) NOT NULL, 
	"PayloadURL" TEXT NOT NULL, 
	"ContentType" VARCHAR(255) NOT NULL, 
	"Headers" JSON, 
	"VerifySSL" BOOLEAN NOT NULL, 
	"SubscribedActions" JSON, 
	"IsActive" BOOLEAN NOT NULL, 
	"CreationDate" DATETIME DEFAULT CURRENT_TIMESTAMP NOT NULL, 
	"Notes" TEXT, 
	PRIMARY KEY ("WebHookID")
);
CREATE TABLE "NewConfigurationTemplates" (
	"TemplateID" VARCHAR(255) NOT NULL, 
	"Subnet" VARCHAR(255), 
	"ListenPortStart" INTEGER, 
	"ListenPortEnd" INTEGER, 
	"Notes" TEXT, 
	PRIMARY KEY ("TemplateID")
);
CREATE TABLE "PeerShareLinks" (
	"ShareID" VARCHAR(255) NOT NULL, 
	"Configuration" VARCHAR(255) NOT NULL, 
	"Peer" VARCHAR(255) NOT NULL, 
	"ExpireDate" DATETIME, 
	"SharedDate" DATETIME DEFAULT CURRENT_TIMESTAMP, 
	PRIMARY KEY ("ShareID")
);
CREATE TABLE wg0 (
	id VARCHAR(255) NOT NULL, 
	private_key VARCHAR(255), 
	"DNS" TEXT, 
	endpoint_allowed_ip TEXT, 
	name TEXT, 
	total_receive FLOAT, 
	total_sent FLOAT, 
	total_data FLOAT, 
	endpoint VARCHAR(255), 
	status VARCHAR(255), 
	latest_handshake VARCHAR(255), 
	allowed_ip VARCHAR(255), 
	cumu_receive FLOAT, 
	cumu_sent FLOAT, 
	cumu_data FLOAT, 
	mtu INTEGER, 
	keepalive INTEGER, 
	notes TEXT, 
	remote_endpoint VARCHAR(255), 
	preshared_key VARCHAR(255), 
	restricted_reason VARCHAR(255), 
	PRIMARY KEY (id)
);
CREATE TABLE wg0_deleted (
	id VARCHAR(255) NOT NULL, 
	private_key VARCHAR(255), 
	"DNS" TEXT, 
	endpoint_allowed_ip TEXT, 
	name TEXT, 
	total_receive FLOAT, 
	total_sent FLOAT, 
	total_data FLOAT, 
	endpoint VARCHAR(255), 
	status VARCHAR(255), 
	latest_handshake VARCHAR(255), 
	allowed_ip VARCHAR(255), 
	cumu_receive FLOAT, 
	cumu_sent FLOAT, 
	cumu_data FLOAT, 
	mtu INTEGER, 
	keepalive INTEGER, 
	notes TEXT, 
	remote_endpoint VARCHAR(255), 
	preshared_key VARCHAR(255), 
	restricted_reason VARCHAR(255), 
	PRIMARY KEY (id)
);
CREATE TABLE wg0_history_endpoint (
	id VARCHAR(255) NOT NULL, 
	endpoint VARCHAR(255) NOT NULL, 
	time DATETIME
);
CREATE TABLE wg0_restrict_access (
	id VARCHAR(255) NOT NULL, 
	private_key VARCHAR(255), 
	"DNS" TEXT, 
	endpoint_allowed_ip TEXT, 
	name TEXT, 
	total_receive FLOAT, 
	total_sent FLOAT, 
	total_data FLOAT, 
	endpoint VARCHAR(255), 
	status VARCHAR(255), 
	latest_handshake VARCHAR(255), 
	allowed_ip VARCHAR(255), 
	cumu_receive FLOAT, 
	cumu_sent FLOAT, 
	cumu_data FLOAT, 
	mtu INTEGER, 
	keepalive INTEGER, 
	notes TEXT, 
	remote_endpoint VARCHAR(255), 
	preshared_key VARCHAR(255), 
	restricted_reason VARCHAR(255), 
	PRIMARY KEY (id)
);
CREATE TABLE wg0_transfer (
	id VARCHAR(255) NOT NULL, 
	total_receive FLOAT, 
	total_sent FLOAT, 
	total_data FLOAT, 
	cumu_receive FLOAT, 
	cumu_sent FLOAT, 
	cumu_data FLOAT, 
	time DATETIME DEFAULT CURRENT_TIMESTAMP
);
INSERT INTO "ConfigurationsInfo" ("ID", "Info") VALUES ('wg0', '{"Description":"","OverridePeerSettings":{"DNS":"","EndpointAllowedIPs":"","MTU":"","PersistentKeepalive":"","PeerRemoteEndpoint":"","ListenPort":""},"PeerGroups":{},"PeerTrafficTracking":true,"PeerHistoricalEndpointTracking":true}');
INSERT INTO wg0 (id, private_key, "DNS", endpoint_allowed_ip, name, total_receive, total_sent, total_data, endpoint, status, latest_handshake, allowed_ip, cumu_receive, cumu_sent, cumu_data, mtu, keepalive, notes, remote_endpoint, preshared_key, restricted_reason) VALUES ('xyz123', '', '1.1.1.1', '0.0.0.0/0', '', 0.0, 0.0, 0.0, 'N/A', 'stopped', 'N/A', '10.0.0.2/32', 0.0, 0.0, 0.0, 1420, 21, '', '172.18.0.1', '', NULL);