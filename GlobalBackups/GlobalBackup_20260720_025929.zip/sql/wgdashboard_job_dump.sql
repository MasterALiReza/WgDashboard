CREATE TABLE "PeerJobs" (
	"JobID" VARCHAR(255) NOT NULL, 
	"Configuration" VARCHAR(255) NOT NULL, 
	"Peer" VARCHAR(255) NOT NULL, 
	"Field" VARCHAR(255) NOT NULL, 
	"Operator" VARCHAR(255) NOT NULL, 
	"Value" VARCHAR(255) NOT NULL, 
	"CreationDate" DATETIME NOT NULL, 
	"ExpireDate" DATETIME, 
	"Action" VARCHAR(255) NOT NULL, 
	PRIMARY KEY ("JobID")
);